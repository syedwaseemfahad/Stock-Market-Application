import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthenticateService } from '../authenticate.service';
import { User } from '../models/user';
import { order } from '../models/order';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  search:any=''
  phone:string='';
  link;
  orders:order[]=[];
  order:order;
  itr:number=0;
  limit1:number=0;
  limit2:number=7;
  partial:string='Partially Executed';
  complete:string='Completely Executed';

  company:any[]=['Amazon','Google','Paypal','Apple','Facebook'];

    constructor(private router: Router,private http:HttpClient,private validateservice: AuthenticateService) { }
    ngOnInit(): void {
      this.phone=this.validateservice.number
         this.validateservice.getOrdersByPhone(this.phone)
   .subscribe(response => {
    response.forEach((item,index)=>{
      var obj:order;
      console.log(item.noOfShares)
      obj={
        orderId: item.orderId,
    share_companyId: item.share_companyId,
    noOfShares:item.noOfShares,
    price: item.price,
    type:item.type
      }
     this.orders.push(obj)
  });
    });
    
    }
   
    selectNumber(id)
    {
     this.validateservice.deleteOrderById(id);
     this.router.navigate(['deposit'])
    }

   
}
