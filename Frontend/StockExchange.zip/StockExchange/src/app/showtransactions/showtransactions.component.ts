import { Component, OnInit } from '@angular/core';
import { Transaction } from '../models/transaction';
import { AuthenticateService } from '../authenticate.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { order } from '../models/order';

@Component({
  selector: 'app-showtransactions',
  templateUrl: './showtransactions.component.html',
  styleUrls: ['./showtransactions.component.css']
})
export class ShowtransactionsComponent implements OnInit {
  itr=0;
  search:any=''
  phone:string='';
  link;
  orders:order[]=[];
  searchtrans:Transaction[]=[];
  order:order;
  limit1=0
  limit2=7
  slimit1=0
  slimit2=0
  var1=0
  var2=0
  var3=0
  var4=0
  var5=0
  constructor(private router: Router,private http:HttpClient,private validateservice: AuthenticateService) { }

  ngOnInit(): void {
    this.phone=this.validateservice.number
  
       this.validateservice.getOrdersByPhone(this.phone)
 .subscribe(response => {
  response.forEach((item,index)=>{
    var obj;
    obj={
      id: item.orderId,
  share_companyId: item.share_companyId,
  noOfShares:item.noOfShares,
  price: item.price,
  type:item.price
    }
    this.order=obj
    //console.log(this.transobj)
   this.orders.push(this.order)
});
  });
  
  }
  createExchangeAndSort()
  {
    this.validateservice.sort();
    this.router.navigate(['login'])

  }
 
}
