import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthenticateService } from '../authenticate.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  json={}
  orderId:number;
	share_companyId:number;
	noOfShares:number;
	price:number;
	type:string;
	
Amount:number;
phone:string='';
link;
name;
amountDescription='';
var:boolean=true;
  constructor(private router: Router,private http:HttpClient,private validateservice: AuthenticateService) { }
  ngOnInit(): void {
  }
  deposit()
  {
    this.json['orderId']=0;
  this.json['share_companyId']=this.share_companyId
  this.json['noOfShares']=this.noOfShares
  this.json['price']=this.price
  this.json['type']=this.type

 this.validateservice.addOrderToUser(this.json,this.validateservice.number);
  this.router.navigate(['fundtransfer'])

}
  // changeAmount200()
  // {
  //   this.Amount=200;
  // }
  // changeAmount500()
  // {
  //   this.Amount=500;
  // }changeAmount1000()
  // {
  //   this.Amount=1000;
  // }
}
