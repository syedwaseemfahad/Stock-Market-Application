export class order{
    orderId:number;
    share_companyId: number;
    noOfShares: number;
    price: number;
    type: string;
}

