export class User{
    name: string;
    mobileNumber: string;
    password: string;
    email: string;
    accountNumber:string;
    balance:number;
}