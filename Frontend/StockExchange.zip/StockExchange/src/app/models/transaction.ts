
export class Transaction {
    id: string;
    accountNumber: string;
    type: string;
    amount: number;
    time:string;
    balance: number;
}