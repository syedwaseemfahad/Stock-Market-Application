export class Users{
    userId:number;
    userName: string;
    mobileNumber: string;
    password: string;
    email: string;
    orders:any
}